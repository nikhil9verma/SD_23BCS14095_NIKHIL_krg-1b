# Multi-Instance Auth Demo Progress

## ✅ Completed
- [x] Created `multi-auth-demo.bat` — double-click to launch:
  * Registry (3001) + Gateway (3000)
  * Auth Instance 1 (5001) 
  * Auth Instance 2 (5007)
* Dashboard: `http://localhost:3001/dashboard` shows both
* Test rotation + failure tolerance

## ⏳ Next Steps
- [ ] Run `multi-auth-demo.bat`
- [ ] Show interviewer:
  1. Dashboard → 2 instances UP
  2. `curl http://localhost:3000/api/auth/*` → rotates ports
  3. Kill one instance → registry marks DOWN → curls skip it
  4. Restart → auto-recovers

## Demo Commands (manual alternative):
```
multi-auth-demo.bat
# OR manually:
npm run start:registry & npm run start:gateway
cd services/auth-service && set PORT=5001 && npm start
cd services/auth-service && set PORT=5007 && npm start
```

